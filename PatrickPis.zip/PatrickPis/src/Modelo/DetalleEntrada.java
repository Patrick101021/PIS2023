/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package Modelo;

/**
 *
 * @author Jonathan
 */
public class DetalleEntrada extends Movimiento{
    
    private int idDetalleEntradaProducto;
    private int idEntradaProducto;
    private int idProducto;

    public int getIdDetalleEntradaProducto() {
        return idDetalleEntradaProducto;
    }

    public void setIdDetalleEntradaProducto(int idDetalleEntradaProducto) {
        this.idDetalleEntradaProducto = idDetalleEntradaProducto;
    }

    public int getIdEntradaProducto() {
        return idEntradaProducto;
    }

    public void setIdEntradaProducto(int idEntradaProducto) {
        this.idEntradaProducto = idEntradaProducto;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public void setIdProducto(int idProducto) {
        this.idProducto = idProducto;
    }

    
}
